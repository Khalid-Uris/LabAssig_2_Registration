﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabAssig_2_Registration
{
    public partial class Form1 : Form
    {
        string value = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string value = "";

            value += txtFname.Text + "\n";
            value += txtLname.Text + "\n";
            value += txtMathor.Text + "\n";
            value += txtdate.Value.ToString("dd/MM/yyyy")+"\n";
            value += cmbCountry.Text + "\n";
            value += rbMale.Checked ? "Male" : "Female" + "\n";
            value += txtemail.Text + "\n";
            value += txtpassword.Text + "\n";
            value += txtConfirmpassword.Text + "\n";
            value += txtMobileNo.Text + "\n";
            value += txtCapt.Text + "\n";

            
            

            MessageBox.Show(value);


            txtFname.Clear();
            txtLname.Clear();
            txtMathor.Clear();
            cmbCountry.Text = "";
            txtemail.Clear();
            txtpassword.Clear();
            txtConfirmpassword.Clear();
            txtMobileNo.Clear();
            txtCapt.Clear();

            MessageBox.Show("Registered Successfull", "Registration Form", MessageBoxButtons.OK, MessageBoxIcon.Information);



        }

        private void button5_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                //MessageBox.Show(value);
                //MessageBox.Show("Registered Successfull", "Registration Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

            }
        }

        private void txtFname_TextChanged(object sender, EventArgs e)
        {
            if(txtFname==null)
            {
                MessageBox.Show("Enter First Name", "Registration Form", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }

        private void txtConfirmpassword_TextChanged(object sender, EventArgs e)
        {
            if(txtpassword==txtConfirmpassword)
            {
                label4.ForeColor = Color.Red;
                label4.Text = "Right Password";
            }
            else
            {
                label4.ForeColor = Color.Red;
                label4.Text = "Wrong Password";
            }
        }
    }
}
